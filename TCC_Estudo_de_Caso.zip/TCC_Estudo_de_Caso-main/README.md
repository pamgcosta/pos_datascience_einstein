# TCC_Estudo_de_Caso
Estudo de caso de uma arquitetura simplificada para aplicação de dados e análises.

1° Etapa do Projeto: Configuração e aplicação do Airflow para automatização de processo;

2° Etapa do Projeto: Consultas para criação de tabelas clean que serão fonte de dados para dashboard.
